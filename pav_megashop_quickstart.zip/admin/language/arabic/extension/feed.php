<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title']    = 'تغذية المنتجات';

// Text
$_['text_success']     = 'Success: You have modified feeds!';
$_['text_list']        = 'Feed List';


// Column
$_['column_name']      = 'اسم التغذية';
$_['column_status']    = 'الحالة';
$_['column_action']    = 'تحرير';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل!';
